IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Study102CrfEvent]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Study102CrfEvent]
GO
/**************************************************************************
Created On : 3/29/2014
Created By : Aaron Black
Team Name : Informatics
Object name : [usp_Study102CrfEvent]
Functional : ITMI SSIS for Insert and Update for study 102 tblCrfEvent
 Which is attaching subjects to other entities, including family, original site where the subject was enrolled.
History : Created on 3/29/2014
**************************************************************************
Date Modified By QC# Purposes
**************************************************************************
#Date #Comment
**************************************************************************
USE CASE:
EXEC [usp_Study102CrfEvent]
--TRUNCATe table ITMIDW.[dbo].[tblOrganization] 
--select * from ITMIDW.[dbo].[tblOrganization] 

**************************************************************************/
CREATE PROCEDURE [dbo].[usp_Study102CrfEvent]
AS
BEGIN
SET NOCOUNT ON;
DECLARE @UpdatedOn SMALLDATETIME
SET @UpdatedOn = CAST(GETDATE() AS SMALLDATETIME)
PRINT CONVERT(CHAR(23), @UpdatedOn, 121) + ' [usp_Study102CrfEvent][' + @@SERVERNAME + '][' + SYSTEM_USER + ']'
PRINT 'INSERT [ITMIDW].[dbo].[usp_Study102CrfEvent]...'

--*************************************
--******************102****************
--*************************************
--drop table
IF OBJECT_ID('tempdb..#sourceCrfEvent') IS NOT NULL
DROP TABLE #sourceCrfEvent


SELECT DISTINCT
           deets.recordID as [sourceSystemCrfEventID]
           ,NULL AS [parentCrfEventID]
           ,crf.crfID as [crfID]
           ,deets.itmiFormName as [crfType]
           ,crf.crfID as [crfVersionID] --at this time the ID' are the same **Change control** if now versions of the forms need to be tracked.
           ,subject.subjectID as [subjectID]
           ,NULL as [crfStatus]
           ,MAX(itmidw.dbo.dateonly(RaveCreatedDateTime)) as  [updatedDate]
           ,MIN(itmidw.dbo.dateonly(revieweddatetime))  as [completedDate]
           , (select studyID from itmidw.dbo.tblstudy where [studyShortID] like '%102%') as StudyId
           ,NULL as [eventCrfUUID]
           ,(SELECT ss.sourceSystemID FROM ITMIDW.DBO.tblSourceSystem ss WHERE ss.sourceSystemSHortName = 'DIFZ') as [orgSourceSystemID]
           ,GETDATE() [createDate]
           ,'usp_Study102CrfEvent' as [createdBy]
INTO #sourceCrfEvent
FROM itmiDIFZ.genesis.PatientDataPointDetail as deets
	INNER JOIN ITMIDW.dbo.tblSubject subject
		ON subject.subjectId = deets.itmidwSubjectID
	INNER JOIn ITMIDW.dbo.tblCrf crf
		ON crf.crfName = deets.itmiFormName
WHERE deets.isactive = 1	
GROUP BY 
      deets.recordID
      ,crf.crfID 
      ,deets.itmiFormName
      ,subject.subjectID


		

--Slowly changing dimension
MERGE  ITMIDW.[dbo].[tblCrfEvent] AS targetCrfEvent
USING #sourceCrfEvent ss
	ON targetCrfEvent.[sourceSystemCrfEventID] = ss.[sourceSystemCrfEventID]
  WHEN MATCHED
	AND (
           ss.[crfID] <>  targetCrfEvent.[crfID] OR
           ss.[crfType] <> targetCrfEvent.[crfType] OR 
           ss.[crfVersionID] <>  targetCrfEvent.[crfVersionID] OR 
           ss.[subjectID] <> targetCrfEvent.[subjectID] OR 
           ss.[crfStatus] <> targetCrfEvent.[crfStatus] OR 
           ss.[updatedDate] <> targetCrfEvent.[updatedDate] OR 
           ss.[completedDate] <> targetCrfEvent.[completedDate] OR 
           ss.[studyID] <> targetCrfEvent.[studyID] OR 
           ss.[eventCrfUUID] <> targetCrfEvent.[eventCrfUUID] OR 
		 ss.[orgSourceSystemID] <> targetCrfEvent.[orgSourceSystemID] OR  
		ss.[createDate] <> targetCrfEvent.[createDate] OR
		ss.[createdBy] <> targetCrfEvent.[createdBy] 
	)
THEN UPDATE SET
           [crfID]  = ss.[crfID]
           ,[crfType] =ss.[crfType] 
           ,[crfVersionID]=   ss.[crfVersionID] 
           ,[subjectID] = ss.[subjectID] 
           ,[crfStatus]= ss.[crfStatus] 
           ,[updatedDate] = ss.[updatedDate] 
           ,[completedDate] = ss.[completedDate] 
           ,[studyID] = ss.[studyID] 
           ,[eventCrfUUID] = ss.[eventCrfUUID] 
	, [orgSourceSystemID] = ss.[orgSourceSystemID]
	, [createDate] = ss.[createDate] 
	, [createdBy] = ss.[createdBy] 
WHEN NOT MATCHED THEN

INSERT (    [sourceSystemCrfEventID]
			, [crfID]
           ,[crfType]
           ,[crfVersionID]
           ,[subjectID]
           ,[crfStatus]
           ,[updatedDate]
           ,[completedDate]
           ,[studyID]
           ,[eventCrfUUID]
		,[orgSourceSystemID],[createDate],[createdBy])
VALUES (ss.[sourceSystemCrfEventID]
, ss.[crfID]
           ,ss.[crfType]
           ,ss.[crfVersionID]
           ,ss.[subjectID]
           ,ss.[crfStatus]
           ,ss.[updatedDate]
           ,ss.[completedDate]
           ,ss.[studyID]
           ,ss.[eventCrfUUID]
			,ss.[orgSourceSystemID],ss.[createDate],ss.[createdBy]);



END



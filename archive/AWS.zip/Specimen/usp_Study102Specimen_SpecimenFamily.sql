IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Study102Specimen_SpecimenFamily]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Study102Specimen_SpecimenFamily]
GO
/**************************************************************************
Created On : 3/29/2014
Created By : Aaron Black
Team Name : Informatics
Object name : [usp_Study102Specimen_SpecimenFamily]
Functional : ITMI SSIS for Insert and Update for study 102 tblSpecimen and TblSpecimenFamily
 Specimen and Specimen Family
History : Created on 3/29/2014
**************************************************************************
Date Modified By QC# Purposes
**************************************************************************
#Date #Comment
**************************************************************************
USE CASE:
EXEC [usp_Study102Specimen_SpecimenFamily]
**************************************************************************/
CREATE PROCEDURE [dbo].[usp_Study102Specimen_SpecimenFamily]
AS
BEGIN
SET NOCOUNT ON;
DECLARE @UpdatedOn SMALLDATETIME
SET @UpdatedOn = CAST(GETDATE() AS SMALLDATETIME)
PRINT CONVERT(CHAR(23), @UpdatedOn, 121) + ' [usp_Study102Specimen_SpecimenFamily][' + @@SERVERNAME + '][' + SYSTEM_USER + ']'
PRINT 'INSERT [ITMIDW].[dbo].[usp_Study102Specimen_SpecimenFamily]...'

--*************************************
--******************102****************
--*************************************
--drop table
IF OBJECT_ID('tempdb..#SourceSpecimen') IS NOT NULL
DROP TABLE #sourceSpecimen

IF OBJECT_ID('tempdb..#sourceSpecimenFamily') IS NOT NULL
DROP TABLE #sourceSpecimenFamily

--nautilus aliquots
SELECT 
			al.ALIQUOT_ID as [sourceSystemSpecimenID]
			,al.EXTERNAL_REFERENCE as specimenBarcode
           , Sub.[subjectID] as SubjectID
           , NULL as [specimenFamilyID] --get later
           , st.specimenSampleTypeID as [specimenSampleTypeID]
           , NULL as [specimenPhysicalTypeID]
           , NULL as [location] --location_ID
           , NULL as [prepType]
           , NULL as [specimenOriginalWeight]
           , al.amount as [weightVolume]
           , NULL as [units]
           , NULL as [pooledFlag]
           , NULL as [disposedFlag]
           , NULL as [receivedFromOutSideOrgFlag]
           , NULL as [createdInErrorFlag]
           , NULL as [isActiveFlag]
           , NULL as [specimenUUID]
           , NULL as [lastNonZeroWeightVolume]
           , NULL as [custodyDate]
           , (SELECT ss.sourceSystemID FROM ITMIDW.DBO.tblSourceSystem ss WHERE ss.sourceSystemSHortName = 'DIFZ') as [orgSourceSystemID]
           , GETDATE() [createDate]
           ,'usp_Study102Specimen_SpecimenFamily' as [createdBy]
INTO #sourceSpecimen
from [nautilus].[ALIQUOT] al
	inner join nautilus.sample sa
		on sa.SAMPLE_ID = al.SAMPLE_ID
	INNER JOIN [nautilus].[CONTAINER_TYPE] ct
		on ct.CONTAINER_TYPE_ID = al.CONTAINER_TYPE_ID
	INNER JOIN nautilus.[ALIQUOT_TEMPLATe] alTemplate
		on alTemplate.ALIQUOT_TEMPLATE_ID = al.ALIQUOT_TEMPLATE_ID
	LEFT JOIN itmidw.dbo.tblSpecimenSampleType st
		on st.specimenTypeName = al.matrix_type
	LEFT JOIN itmidw.dbo.tblSubject sub
		on sub.sourceSystemIDLabel =  replace(LEFT(sa.EXTERNAL_REFERENCE,4) + SUBSTRING(sa.EXTERNAL_REFERENCE,8,10),'[','')

--nautulis sample
INSERT INTO  #sourceSpecimen (
			[sourceSystemSpecimenID]
		   ,specimenBarcode
           , SubjectID
           , [specimenFamilyID] --get later
           , [specimenSampleTypeID]
           , [specimenPhysicalTypeID]
           , [location] --location_ID
           , [prepType]
           , [specimenOriginalWeight]
           , [weightVolume]
           , [units]
           , [pooledFlag]
           , [disposedFlag]
           , [receivedFromOutSideOrgFlag]
           , [createdInErrorFlag]
           , [isActiveFlag]
           , [specimenUUID]
           , [lastNonZeroWeightVolume]
           ,[custodyDate]
           ,[orgSourceSystemID]
           ,[createDate]
           ,[createdBy]

)
SELECT 
			sa.SAMPLE_ID as [sourceSystemSpecimenID]
			,sa.EXTERNAL_REFERENCE as specimenBarcode
           , Sub.[subjectID] as SubjectID
           , NULL as [specimenFamilyID] --get later
           , st.specimenSampleTypeID as [specimenSampleTypeID]
           , NULL as [specimenPhysicalTypeID]
           , NULL as [location] --location_ID
           , NULL as [prepType]
           , NULL as [specimenOriginalWeight]
           , NULL as [weightVolume]
           , NULL as [units]
           , NULL as [pooledFlag]
           , NULL as [disposedFlag]
           , NULL as [receivedFromOutSideOrgFlag]
           , NULL as [createdInErrorFlag]
           , NULL as [isActiveFlag]
           , NULL as [specimenUUID]
           , NULL as [lastNonZeroWeightVolume]
           , NULL as [custodyDate]
           , (SELECT ss.sourceSystemID FROM ITMIDW.DBO.tblSourceSystem ss WHERE ss.sourceSystemSHortName = 'DIFZ') as [orgSourceSystemID]
           , GETDATE() [createDate]
           ,'usp_Study102Specimen_SpecimenFamily' as [createdBy]
	FROM  nautilus.sample sa
		LEFT JOIN itmidw.dbo.tblSubject sub
			on sub.sourceSystemIDLabel =  replace(LEFT(sa.EXTERNAL_REFERENCE,4) + SUBSTRING(sa.EXTERNAL_REFERENCE,8,10),'[','')
		LEFT JOIN itmidw.dbo.tblSpecimenSampleType st
			on st.specimenTypeName = sa.SAMPLE_TYPE


	
		
--SpecimenFamily


--Slowly changing dimension
MERGE  ITMIDW.[dbo].[tblSpecimen] AS targetSpecimen
USING #sourceSpecimen ss
	ON targetSpecimen.[sourceSystemSpecimenID] = ss.[sourceSystemSpecimenID]
WHEN MATCHED
	AND (
		   ss.specimenBarcode <> targetSpecimen.specimenBarcode OR
           ss.SubjectID <> targetSpecimen.SubjectID OR
           ss.[specimenFamilyID]  <> targetSpecimen.[specimenFamilyID] OR
           ss.[specimenSampleTypeID] <> targetSpecimen.specimenSampleTypeID OR
           ss.[specimenPhysicalTypeID] <> targetSpecimen.[specimenPhysicalTypeID] OR
           ss.[location]  <> targetSpecimen.[location] OR
           ss.[prepType] <> targetSpecimen.prepType OR
           ss.[specimenOriginalWeight] <> targetSpecimen.[specimenOriginalWeight] OR
           ss.[weightVolume] <> targetSpecimen.[weightVolume] OR
           ss.[units] <> targetSpecimen.units OR
           ss.[pooledFlag] <> targetSpecimen.pooledFlag OR
           ss.[disposedFlag] <> targetSpecimen.disposedFlag OR
           ss.[receivedFromOutSideOrgFlag] <> targetSpecimen.[receivedFromOutSideOrgFlag] OR
           ss.[createdInErrorFlag] <> targetSpecimen.[createdInErrorFlag] OR
           ss.[isActiveFlag] <> targetSpecimen.[isActiveFlag] OR
           ss.[specimenUUID] <> targetSpecimen.[specimenUUID] OR
           ss.[lastNonZeroWeightVolume] <> targetSpecimen.[lastNonZeroWeightVolume] OR
           ss.[custodyDate] <> targetSpecimen.[custodyDate] OR
		   ss.[orgSourceSystemID] <> targetSpecimen.[orgSourceSystemID] OR  
		   ss.[createDate] <> targetSpecimen.[createDate] OR
		   ss.[createdBy] <> targetSpecimen.[createdBy] 
	)
THEN UPDATE SET
	 	   specimenBarcode = targetSpecimen.specimenBarcode 
           ,SubjectID = targetSpecimen.SubjectID 
           ,[specimenFamilyID]  = targetSpecimen.[specimenFamilyID]
           ,[specimenSampleTypeID] = targetSpecimen.specimenSampleTypeID
           ,[specimenPhysicalTypeID] = targetSpecimen.[specimenPhysicalTypeID]
           ,[location]  = targetSpecimen.[location]
           ,[prepType] = targetSpecimen.prepType
           ,[specimenOriginalWeight] = targetSpecimen.[specimenOriginalWeight]
           ,[weightVolume] = targetSpecimen.[weightVolume]
           ,[units] = targetSpecimen.units
           ,[pooledFlag] = targetSpecimen.pooledFlag
           ,[disposedFlag] = targetSpecimen.disposedFlag
           ,[receivedFromOutSideOrgFlag] = targetSpecimen.[receivedFromOutSideOrgFlag]
           ,[createdInErrorFlag] = targetSpecimen.[createdInErrorFlag]
           ,[isActiveFlag] = targetSpecimen.[isActiveFlag]
           ,[specimenUUID] = targetSpecimen.[specimenUUID]
           ,[lastNonZeroWeightVolume] = targetSpecimen.[lastNonZeroWeightVolume]
           ,[custodyDate] = targetSpecimen.[custodyDate]
		   ,[orgSourceSystemID] = targetSpecimen.[orgSourceSystemID]  
		   ,[createDate] = targetSpecimen.[createDate]
		   ,[createdBy] = targetSpecimen.[createdBy] 

WHEN NOT MATCHED THEN

INSERT (
			[sourceSystemSpecimenID]
		   , specimenBarcode
           , SubjectID
           , [specimenFamilyID] 
           , [specimenSampleTypeID]
           , [specimenPhysicalTypeID]
           , [location]
           , [prepType]
           , [specimenOriginalWeight]
           , [weightVolume]
           , [units]
           , [pooledFlag]
           , [disposedFlag]
           , [receivedFromOutSideOrgFlag]
           , [createdInErrorFlag]
           , [isActiveFlag]
           , [specimenUUID]
           , [lastNonZeroWeightVolume]
           , [custodyDate]
           , [orgSourceSystemID]
           , [createDate]
           , [createdBy]
)
VALUES (
			ss.[sourceSystemSpecimenID]
		   , ss.specimenBarcode
           , ss.SubjectID
           , ss.[specimenFamilyID] 
           , ss.[specimenSampleTypeID]
           , ss.[specimenPhysicalTypeID]
           , ss.[location]
           , ss.[prepType]
           , ss.[specimenOriginalWeight]
           , ss.[weightVolume]
           , ss.[units]
           , ss.[pooledFlag]
           , ss.[disposedFlag]
           , ss.[receivedFromOutSideOrgFlag]
           , ss.[createdInErrorFlag]
           , ss.[isActiveFlag]
           , ss.[specimenUUID]
           , ss.[lastNonZeroWeightVolume]
           , ss.[custodyDate]
           , ss.[orgSourceSystemID]
           , ss.[createDate]
           , ss.[createdBy]
);


END



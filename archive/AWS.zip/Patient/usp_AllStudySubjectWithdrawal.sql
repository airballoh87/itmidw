IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AllStudySubjectWithdrawal]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AllStudySubjectWithdrawal]
GO
/**************************************************************************
Created On : 3/17/2014
Created By : Aaron Black
Team Name : Informatics
Object name : [usp_AllStudySubjectWithdrawal]
Functional : ITMI SSIS for Insert legacy for Subject Withdrawals
Purpose : Takes data from spreadsheets provided by ITMI Clinical Team, adds it to a temp table #t.  Then inserts these subject withdrawals.
History : Created on 3/17/2014
**************************************************************************
Date Modified By QC# Purposes
**************************************************************************
#Date #Comment
**************************************************************************
USE CASE:
EXEC [usp_AllStudySubjectWithdrawal]
select sub.* FROM [ITMIDW].[dbo].[tblSubjectWithDrawal] wi inner join tblsubject sub on sub.subjectID = wi.subjectID
**************************************************************************/
CREATE PROCEDURE [dbo].[usp_AllStudySubjectWithdrawal]
AS
BEGIN
SET NOCOUNT ON;
DECLARE @UpdatedOn SMALLDATETIME
SET @UpdatedOn = CAST(GETDATE() AS SMALLDATETIME)
PRINT CONVERT(CHAR(23), @UpdatedOn, 121) + ' [usp_AllStudySubjectWithdrawal][' + @@SERVERNAME + '][' + SYSTEM_USER + ']'
PRINT 'INSERT [ITMIDW].[dbo].[tblSubjectWithDrawal]...'

--drop table
IF OBJECT_ID('tempdb..#T') IS NOT NULL
DROP TABLE #T  

--Create temp table
SELECT  CONVERT(varchar(100),NULL) as Subject
,CONVERT(varchar(100),NULL) as site
,CONVERT(varchar(100),NULL) as sitenumber
,CONVERT(varchar(100),NULL) as instanceName
,CONVERT(varchar(100),NULL) as folderID
,CONVERT(varchar(100),NULL) as WDDAT_RAW
,CONVERT(varchar(100),NULL) as WDOTH
INTO #T

--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH)
SELECT 
	sub.subjectID
	,  ParticipantWithdrawal.participantID,*
FROM itmidifz.genesis.ParticipantWithdrawal as ParticipantWithdrawal
	INNER JOIN itmidw.dbo.TblSubject sub
		on sub.sourceSystemSubjectID = ParticipantWithdrawal.participantID
WHERE sub.orgSourceSystemID = 3


----Insert study 102 data
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08074','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','03/11/2014','PRIVACY/PERSONAL - CONFIDENTIALITY FOB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08074','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','03/11/2014','PRIVACY/PERSONAL - CONFIDENTIALITY FOB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08074','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','03/11/2014','PRIVACY/PERSONAL - CONFIDENTIALITY FOB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00894','2 - Niederhuber (Andersen)','2','Father - 02','303','03/06/2014','PERSONAL/PRIVACY - SPECIMEN'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00894','2 - Niederhuber (Andersen)','2','Mother - 01','304','03/06/2014','PERSONAL/PRIVACY - SAMPLE RELATED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00894','2 - Niederhuber (Andersen)','2','Newborn - 03','305','03/06/2014','PERSONAL/PRIVACY - SAMPLE RELATED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00911','2 - Niederhuber (Andersen)','2','Father - 02','309','03/06/2014','PRIVACY/PERSONAL - CONFIDENTIALITY FOR NB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00911','2 - Niederhuber (Andersen)','2','Mother - 01','310','03/06/2014','PRIVACY/PERSONAL - CONFIDENTIALITY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00911','2 - Niederhuber (Andersen)','2','Newborn - 03','311','03/06/2014','PRIVACY/PERSONAL - CONFIDENTIALITY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00292','3 - Niederhuber (Khoury)','3','Father - 02','309','03/04/2014','PERSONAL -OVERWHELMED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00292','3 - Niederhuber (Khoury)','3','Mother - 01','310','03/04/2014','PERSONAL-OVERWHELMED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00292','3 - Niederhuber (Khoury)','3','Newborn - 03','311','03/04/2014','PERSONAL-OVERWHELMED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01162','7 - Niederhuber (Wolf)','7','Father - 02','309','03/03/2014','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01162','7 - Niederhuber (Wolf)','7','Mother - 01','310','03/03/2014','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01162','7 - Niederhuber (Wolf)','7','Newborn - 03','311','03/03/2014','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08053','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','02/28/2014','INCOMPLETE TRIO - FOB DECLINED PARTICIPATION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08053','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','02/28/2014','INCOMPLETE TRIO - FOB DECLINED TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08053','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','02/28/2014','INCOMPLETE TRIO - FOB DECLINED TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01411','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','02/27/2014','INCOMPLETE TRIO - FOB DECLINED PARTICIPANTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01411','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','02/27/2014','INCOMPLETE TRIO - FOB DECLINED PARTICIPANTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01411','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','02/27/2014','INCOMPLETE TRIO - FOB DECLINED PARTICIPANTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00284','3 - Niederhuber (Khoury)','3','Father - 02','309','02/26/2014','MOB ELIGIBILITY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00284','3 - Niederhuber (Khoury)','3','Mother - 01','310','02/26/2014','ELIGIBILITY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00284','3 - Niederhuber (Khoury)','3','Newborn - 03','311','02/26/2014','ELIGIBILITY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01381','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','02/14/2014','FOB DOES NOT WANT TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01381','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','02/14/2014','FOB DOES NOT WANT TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01381','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','02/14/2014','FOB DOES NOT WANT TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01445','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','02/12/2014','FOB REQUESTED TO CANCEL STUDY PARTICIPATION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01445','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','02/12/2014','FOB REQUESTED TO CANCEL STUDY PARTICIPATION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01445','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','02/12/2014','FOB REQUESTED TO CANCEL STUDY PARTICIPATION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08016','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','02/11/2014','FOB DOES NOT WISH TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08016','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','02/11/2014','FOB DOES NOT WISH TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-08016','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','02/11/2014','FOB DOES NOT WISH TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00863','2 - Niederhuber (Andersen)','2','Father - 02','303','02/10/2014','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00863','2 - Niederhuber (Andersen)','2','Mother - 01','304','02/10/2014','MOB DOES NOT WANT TO DO DEL SPECIMENS DEL @FOH'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00863','2 - Niederhuber (Andersen)','2','Newborn - 03','305','02/10/2014','MOB DOES NOT WANT TO DO DEL SPECIMENS DEL @FOH'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00633','2 - Niederhuber (Andersen)','2','Mother - 01','310','02/09/2014','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00633','2 - Niederhuber (Andersen)','2','Newborn - 03','311','02/09/2014','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01430','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','01/31/2014','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01430','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','01/31/2014','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01430','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','01/31/2014','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01520','6 - Niederhuber (Inova Fairfax Hospital)','6','Father - 02','309','01/27/2014','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01520','6 - Niederhuber (Inova Fairfax Hospital)','6','Mother - 01','310','01/27/2014','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01520','6 - Niederhuber (Inova Fairfax Hospital)','6','Newborn - 03','311','01/27/2014','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01511','6 - Niederhuber (Inova Fairfax Hospital)','6','Father - 02','303','01/20/2014','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01511','6 - Niederhuber (Inova Fairfax Hospital)','6','Mother - 01','304','01/20/2014','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01511','6 - Niederhuber (Inova Fairfax Hospital)','6','Newborn - 03','305','01/20/2014','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00275','3 - Niederhuber (Khoury)','3','Father - 02','303','01/14/2014','MOB/FOB DO NOT WISH TO CONTINUE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00275','3 - Niederhuber (Khoury)','3','Mother - 01','304','01/14/2014','MOB/FOB DO NOT WISH TO CONTINUE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00275','3 - Niederhuber (Khoury)','3','Newborn - 03','305','01/14/2014','MOB/FOB DO NOT WISH TO CONTINUE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01387','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','1/14/2014','FOB DECLINED BABYS BLOOD SAMPLE PER MOB.'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01387','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','01/14/2014','FOB DECLINED BABYS BLOOD SAMPLE PER MOB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01387','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','01/14/2014','FOB DECLINED BABYS BLOOD SAMPLE PER MOB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00850','2 - Niederhuber (Andersen)','2','Father - 02','303','12/27/2013','FOB DECISION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00850','2 - Niederhuber (Andersen)','2','Mother - 01','304','12/27/2013','FOB DECISION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00850','2 - Niederhuber (Andersen)','2','Newborn - 03','305','12/27/2013','FOB DECISION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00750','2 - Niederhuber (Andersen)','2','Father - 02','303','12/22/2013','INCOMPLETE TRIO & SPECIMEN COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00750','2 - Niederhuber (Andersen)','2','Mother - 01','304','12/22/2013','INCOMPLETE TRIO & SPECIMEN COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00750','2 - Niederhuber (Andersen)','2','Newborn - 03','305','12/22/2013','INCOMPLETE TRIO & SPECIMEN COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01341','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','12/22/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01341','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','12/22/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01341','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','12/22/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01484','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','12/02/2013','MOB DELIVERED AT IAH. FOB DECLINED BABYS BLOOD.'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01484','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','12/02/2013','DELIVERED AT IAH. MOB DECLINES BABYS BLOOD DRAW.'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01484','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','12/02/2013','DELIVERED AT IAH. MOB DECLINES BABYS BLOOD DRAW.'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00857','2 - Niederhuber (Andersen)','2','Father - 02','303','11/30/2013','LAB RELATED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00857','2 - Niederhuber (Andersen)','2','Mother - 01','304','11/30/2013','LAB RELATED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00857','2 - Niederhuber (Andersen)','2','Newborn - 03','305','11/30/2013','LAB RELATED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01332','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','11/27/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01332','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','11/27/2013','NO PRENATAL BLOOD COLLECTED BEFORE DELIVERY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01332','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','11/27/2013','NO PRENATAL BLOOD COLLECTED BEFORE DELIVERY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00178','4 - Niederhuber (Maser)','4','Father - 02','303','11/19/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00178','4 - Niederhuber (Maser)','4','Mother - 01','304','11/19/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00178','4 - Niederhuber (Maser)','4','Newborn - 03','305','11/19/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01408','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','11/15/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01408','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','11/15/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01408','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','11/15/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01133','7 - Niederhuber (Wolf)','7','Father - 02','303','11/14/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01133','7 - Niederhuber (Wolf)','7','Mother - 01','304','11/14/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01133','7 - Niederhuber (Wolf)','7','Newborn - 03','305','11/14/2013','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01407','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','11/12/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01407','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','11/12/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01407','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','11/12/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00862','2 - Niederhuber (Andersen)','2','Father - 02','303','11/08/2013','PRIVACY RELATED RESEAONS, MOB & FOB BOTH WITHDREW'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00862','2 - Niederhuber (Andersen)','2','Mother - 01','304','11/08/2013','PRIVACY RELATED RESEAONS, MOB & FOB BOTH WITHDREW'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00862','2 - Niederhuber (Andersen)','2','Newborn - 03','305','11/08/2013','PRIVACY RELATED RESEAONS, MOB & FOB BOTH WITHDREW'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00839','2 - Niederhuber (Andersen)','2','Father - 02','303','11/05/2013','INCOMPLETE TRIO- MOB WITHDREW W/FOB DECLINED BLOOD'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00839','2 - Niederhuber (Andersen)','2','Mother - 01','304','11/05/2013','INCOMPLETE TRIO- MOB WITHDREW W/FOB DECLINED BLOOD'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00839','2 - Niederhuber (Andersen)','2','Newborn - 03','305','11/05/2013','INCOMPLETE TRIO- MOB WITHDREW W/FOB DECLINED BLOOD'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01370','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','11/01/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01370','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','11/01/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01370','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','11/01/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01382','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','303','10/28/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01382','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','304','10/28/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01382','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','305','10/28/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00815','2 - Niederhuber (Andersen)','2','Father - 02','309','10/18/2013','MOB DECLINED DELIVERY SAMPLE COLLECTION & FOR NB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00815','2 - Niederhuber (Andersen)','2','Mother - 01','310','10/18/2013','MOB DECLINED DELIVERY SAMPLE COLLECTION & FOR NB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00815','2 - Niederhuber (Andersen)','2','Newborn - 03','311','10/18/2013','MOB DECLINED DELIVERY SAMPLE COLLECTION & FOR NB'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00253','3 - Niederhuber (Khoury)','3','Father - 02','309','10/15/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00253','3 - Niederhuber (Khoury)','3','Mother - 01','310','10/15/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00253','3 - Niederhuber (Khoury)','3','Newborn - 03','311','10/15/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00154','4 - Niederhuber (Maser)','4','Father - 02','309','10/14/2013','DELIVERY SAMPLES MISSED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00154','4 - Niederhuber (Maser)','4','Mother - 01','310','10/14/2013','DELIVERY SAMPLES MISSED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00154','4 - Niederhuber (Maser)','4','Newborn - 03','311','10/14/2013','DELIVERY SAMPLES MISSED'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00836','2 - Niederhuber (Andersen)','2','Father - 02','309','10/13/2013','DUPLICATE ENTRY OF FAMILY INTO EDC'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00836','2 - Niederhuber (Andersen)','2','Mother - 01','310','10/13/2013','DUPLICATE ENTRY OF FAMILY INTO EDC'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00836','2 - Niederhuber (Andersen)','2','Newborn - 03','311','10/13/2013','DUPLICATE ENTRY OF FAMILY INTO EDC'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01102','7 - Niederhuber (Wolf)','7','Father - 02','309','10/07/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01102','7 - Niederhuber (Wolf)','7','Mother - 01','310','10/07/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01102','7 - Niederhuber (Wolf)','7','Newborn - 03','311','10/07/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01505','6 - Niederhuber (Inova Fairfax Hospital)','6','Father - 02','309','10/04/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01505','6 - Niederhuber (Inova Fairfax Hospital)','6','Mother - 01','310','10/04/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01505','6 - Niederhuber (Inova Fairfax Hospital)','6','Newborn - 03a','311','10/04/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01505','6 - Niederhuber (Inova Fairfax Hospital)','6','Newborn - 03b','311','10/04/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01284','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','10/02/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01284','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','10/02/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01284','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','10/02/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00859','2 - Niederhuber (Andersen)','2','Father - 02','309','10/01/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00859','2 - Niederhuber (Andersen)','2','Mother - 01','310','10/01/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00859','2 - Niederhuber (Andersen)','2','Newborn - 03','311','10/01/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00166','4 - Niederhuber (Maser)','4','Father - 02','309','09/24/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00166','4 - Niederhuber (Maser)','4','Mother - 01','310','09/24/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00166','4 - Niederhuber (Maser)','4','Newborn - 03','311','09/24/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00757','2 - Niederhuber (Andersen)','2','Father - 02','309','09/22/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00757','2 - Niederhuber (Andersen)','2','Mother - 01','310','09/22/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00757','2 - Niederhuber (Andersen)','2','Newborn - 03','311','09/22/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00852','2 - Niederhuber (Andersen)','2','Father - 02','309','09/18/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00852','2 - Niederhuber (Andersen)','2','Mother - 01','310','09/18/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00852','2 - Niederhuber (Andersen)','2','Newborn - 03','311','09/18/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01069','7 - Niederhuber (Wolf)','7','Father - 02','309','09/15/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01069','7 - Niederhuber (Wolf)','7','Mother - 01','310','09/15/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01069','7 - Niederhuber (Wolf)','7','Newborn - 03','311','09/15/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00825','2 - Niederhuber (Andersen)','2','Father - 02','309','09/12/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00825','2 - Niederhuber (Andersen)','2','Mother - 01','310','09/12/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00825','2 - Niederhuber (Andersen)','2','Newborn - 03','311','09/12/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00156','4 - Niederhuber (Maser)','4','Father - 02','309','09/11/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00156','4 - Niederhuber (Maser)','4','Mother - 01','310','09/11/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00156','4 - Niederhuber (Maser)','4','Newborn - 03','311','09/11/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00833','2 - Niederhuber (Andersen)','2','Father - 02','309','09/06/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00833','2 - Niederhuber (Andersen)','2','Mother - 01','310','09/06/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00833','2 - Niederhuber (Andersen)','2','Newborn - 03','311','09/06/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01011','7 - Niederhuber (Wolf)','7','Father - 02','309','08/25/2013','FAMILY ASKED TO W/D DUE TO FOB TRYPANOPHOBIA'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01011','7 - Niederhuber (Wolf)','7','Mother - 01','310','08/25/2013','FAMILY ASKED TO W/D DUE TO FOB TRYPANOPHOBIA'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01011','7 - Niederhuber (Wolf)','7','Newborn - 03','311','08/25/2013','FAMILY ASKED TO W/D DUE TO FOB TRYPANOPHOBIA'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01299','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','08/22/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01299','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','08/22/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01299','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','08/22/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01076','7 - Niederhuber (Wolf)','7','Father - 02','309','08/21/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01076','7 - Niederhuber (Wolf)','7','Mother - 01','310','08/21/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01076','7 - Niederhuber (Wolf)','7','Newborn - 03','311','08/21/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01319','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','08/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01319','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','08/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01319','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','08/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00761','2 - Niederhuber (Andersen)','2','Father - 02','303','08/16/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00761','2 - Niederhuber (Andersen)','2','Mother - 01','304','08/16/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00761','2 - Niederhuber (Andersen)','2','Newborn - 03','305','08/16/2013','INCOMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01331','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','08/15/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01331','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','08/15/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01331','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','08/15/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00744','2 - Niederhuber (Andersen)','2','Father - 02','309','08/09/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00744','2 - Niederhuber (Andersen)','2','Mother - 01','310','08/09/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00744','2 - Niederhuber (Andersen)','2','Newborn - 03','311','08/09/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01061','7 - Niederhuber (Wolf)','7','Father - 02','309','08/04/2013','DUPLICATE STUDY NUMBER'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01061','7 - Niederhuber (Wolf)','7','Mother - 01','310','08/04/2013','DUPLICATE STUDY NUMBER'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01061','7 - Niederhuber (Wolf)','7','Newborn - 03','311','08/04/2013','DUPLICATE STUDY NUMBER'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01064','7 - Niederhuber (Wolf)','7','Father - 02','309','08/04/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01064','7 - Niederhuber (Wolf)','7','Mother - 01','310','08/04/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01064','7 - Niederhuber (Wolf)','7','Newborn - 03','311','08/04/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01320','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','07/30/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01320','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','07/30/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01309','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','07/30/2013','MOVING/CHANGE OF DELIVERY HOSPITAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01309','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','07/30/2013','MOVING/CHANGE OF DELIVERY HOSPITAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01309','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','07/30/2013','MOVING/CHANGE OF DELIVERY HOSPITAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00807','2 - Niederhuber (Andersen)','2','Father - 02','309','07/26/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00807','2 - Niederhuber (Andersen)','2','Mother - 01','310','07/26/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00807','2 - Niederhuber (Andersen)','2','Newborn - 03','311','07/26/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00252','3 - Niederhuber (Khoury)','3','Father - 02','309','07/24/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00252','3 - Niederhuber (Khoury)','3','Mother - 01','310','07/24/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00252','3 - Niederhuber (Khoury)','3','Newborn - 03','311','07/24/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01320','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','07/15/2013','PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00753','2 - Niederhuber (Andersen)','2','Father - 02','309','07/08/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00753','2 - Niederhuber (Andersen)','2','Mother - 01','310','07/08/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00753','2 - Niederhuber (Andersen)','2','Newborn - 03','311','07/08/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01302','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','07/08/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01302','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','07/08/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01302','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','07/08/2013','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00676','2 - Niederhuber (Andersen)','2','Father - 02','309','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00676','2 - Niederhuber (Andersen)','2','Mother - 01','310','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00676','2 - Niederhuber (Andersen)','2','Newborn - 03','311','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01062','7 - Niederhuber (Wolf)','7','Father - 02','309','07/05/2013','FOB DECLINED TO PARTICIPATE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01062','7 - Niederhuber (Wolf)','7','Mother - 01','310','07/05/2013','FOB DECLINED PARTICIPATION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01062','7 - Niederhuber (Wolf)','7','Newborn - 03','311','07/05/2013','FOB DECLINED PARTICIPATION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01226','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01226','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01226','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01257','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01257','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01257','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','07/05/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01306','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','07/04/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01306','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','07/04/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01306','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','07/04/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01021','7 - Niederhuber (Wolf)','7','Father - 02','309','06/21/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01021','7 - Niederhuber (Wolf)','7','Mother - 01','310','06/21/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01021','7 - Niederhuber (Wolf)','7','Newborn - 03','311','06/21/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00254','3 - Niederhuber (Khoury)','3','Father - 02','309','06/19/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00254','3 - Niederhuber (Khoury)','3','Mother - 01','310','06/19/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00254','3 - Niederhuber (Khoury)','3','Newborn - 03','311','06/19/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01313','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','06/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01313','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','06/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01313','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03a','311','06/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01313','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03b','311','06/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00241','3 - Niederhuber (Khoury)','3','Father - 02','309','06/11/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00241','3 - Niederhuber (Khoury)','3','Mother - 01','310','06/11/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00241','3 - Niederhuber (Khoury)','3','Newborn - 03','311','06/11/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01211','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','05/01/2013','MOVING/CHANGE OF DELIVERY HOSPITAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01211','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','05/01/2013','MOVING/CHANGED DELIVERY HOSPITAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01211','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','05/01/2013','MOVING/CHANGED DELIVERY HOSPITAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00701','2 - Niederhuber (Andersen)','2','Father - 02','309','04/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01048','7 - Niederhuber (Wolf)','7','Father - 02','309','04/17/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00701','2 - Niederhuber (Andersen)','2','Mother - 01','310','04/14/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00701','2 - Niederhuber (Andersen)','2','Newborn - 03','311','04/14/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01016','7 - Niederhuber (Wolf)','7','Father - 02','309','04/14/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01016','7 - Niederhuber (Wolf)','7','Mother - 01','310','04/14/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01016','7 - Niederhuber (Wolf)','7','Newborn - 03','311','04/14/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01048','7 - Niederhuber (Wolf)','7','Mother - 01','310','04/14/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01048','7 - Niederhuber (Wolf)','7','Newborn - 03','311','04/14/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00633','2 - Niederhuber (Andersen)','2','Father - 02','309','03/14/2013','PROTOCOL NO NCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00131','4 - Niederhuber (Maser)','4','Father - 02','309','03/08/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00131','4 - Niederhuber (Maser)','4','Mother - 01','310','03/08/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00131','4 - Niederhuber (Maser)','4','Newborn - 03','311','03/08/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01206','8 - Niederhuber (Inova OB Clinic)','8','Father - 02','309','03/06/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01206','8 - Niederhuber (Inova OB Clinic)','8','Mother - 01','310','03/06/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01206','8 - Niederhuber (Inova OB Clinic)','8','Newborn - 03','311','03/06/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00646','2 - Niederhuber (Andersen)','2','Father - 02','309','02/27/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00646','2 - Niederhuber (Andersen)','2','Mother - 01','310','02/27/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00646','2 - Niederhuber (Andersen)','2','Newborn - 03','311','02/27/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00723','2 - Niederhuber (Andersen)','2','Father - 02','309','02/25/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00723','2 - Niederhuber (Andersen)','2','Mother - 01','310','02/25/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00723','2 - Niederhuber (Andersen)','2','Newborn - 03','311','02/25/2013','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00694','2 - Niederhuber (Andersen)','2','Father - 02','309','02/01/2013','UNABLE TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00694','2 - Niederhuber (Andersen)','2','Mother - 01','310','02/01/2013','UNABEL TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00694','2 - Niederhuber (Andersen)','2','Newborn - 03','311','02/01/2013','UNABEL TO COMPLETE TRIO'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00594','2 - Niederhuber (Andersen)','2','Father - 02','309','01/14/2013','MISSED @ DELIVERY DECLINED PP SAMPLE COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00594','2 - Niederhuber (Andersen)','2','Mother - 01','310','01/14/2013','MISSED @ DELIVERY DECLINED PP SAMPLE COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00594','2 - Niederhuber (Andersen)','2','Newborn - 03','311','01/14/2013','MISSED @ DELIVERY DECLINED PP SAMPLE COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00656','2 - Niederhuber (Andersen)','2','Father - 02','309','01/07/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00656','2 - Niederhuber (Andersen)','2','Mother - 01','310','01/07/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00656','2 - Niederhuber (Andersen)','2','Newborn - 03','311','01/07/2013','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01008','7 - Niederhuber (Wolf)','7','Father - 02','309','12/28/2012','FOB DECLINE TO PARTICIPATE DUE TO BLOOD DRAW'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01008','7 - Niederhuber (Wolf)','7','Mother - 01','310','12/28/2012','FOB DECLINED TO PARTICIPATE DUE TO BLOOD DRAW'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-01008','7 - Niederhuber (Wolf)','7','Newborn - 03','311','12/28/2012','FOB DECLINED TO PARTICIPATE DUE TO BLOOD DRAW'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00614','2 - Niederhuber (Andersen)','2','Father - 02','309','12/14/2012','MISSED @ DELIVERY DECLINED PP SAMPLE COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00614','2 - Niederhuber (Andersen)','2','Mother - 01','310','12/14/2012','MISSED @ DELIVERY DECLINED PP SAMPLE COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00614','2 - Niederhuber (Andersen)','2','Newborn - 03','311','12/14/2012','MISSED @ DELIVERY DECLINED PP SAMPLE COLLECTION'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00564','2 - Niederhuber (Andersen)','2','Father - 02','309','12/12/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00564','2 - Niederhuber (Andersen)','2','Mother - 01','310','12/12/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00564','2 - Niederhuber (Andersen)','2','Newborn - 03','311','12/12/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00101','4 - Niederhuber (Maser)','4','Father - 02','309','12/12/2012','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00101','4 - Niederhuber (Maser)','4','Mother - 01','310','12/12/2012','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00101','4 - Niederhuber (Maser)','4','Newborn - 03','311','12/12/2012','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00558','2 - Niederhuber (Andersen)','2','Father - 02','309','12/05/2012','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00558','2 - Niederhuber (Andersen)','2','Mother - 01','310','12/05/2012','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00558','2 - Niederhuber (Andersen)','2','Newborn - 03','311','12/05/2012','PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00107','4 - Niederhuber (Maser)','4','Father - 02','309','11/08/2012','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00107','4 - Niederhuber (Maser)','4','Mother - 01','310','11/08/2012','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00107','4 - Niederhuber (Maser)','4','Newborn - 03','311','11/08/2012','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00531','2 - Niederhuber (Andersen)','2','Father - 02','309','10/09/2012','FAMILY ENROLLED ON 101'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00531','2 - Niederhuber (Andersen)','2','Mother - 01','310','10/09/2012','FAMILY ENROLLED ON 101'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00531','2 - Niederhuber (Andersen)','2','Newborn - 03','311','10/09/2012','FAMILY ENROLLED ON 101'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00509','2 - Niederhuber (Andersen)','2','Father - 02','309','09/25/2012','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00509','2 - Niederhuber (Andersen)','2','Mother - 01','310','09/25/2012','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00509','2 - Niederhuber (Andersen)','2','Newborn - 03','311','09/25/2012','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00546','2 - Niederhuber (Andersen)','2','Father - 02','309','09/20/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00546','2 - Niederhuber (Andersen)','2','Mother - 01','310','09/20/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00546','2 - Niederhuber (Andersen)','2','Newborn - 03','311','09/20/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00113','4 - Niederhuber (Maser)','4','Father - 02','309','09/20/2012','PERSONAL/PRIVACY'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00113','4 - Niederhuber (Maser)','4','Mother - 01','310','09/20/2012','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00113','4 - Niederhuber (Maser)','4','Newborn - 03','311','09/20/2012','PRIVACY/PERSONAL'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00507','2 - Niederhuber (Andersen)','2','Father - 02','309','09/13/2012','PRIVACY CONCERNS'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00507','2 - Niederhuber (Andersen)','2','Mother - 01','310','09/13/2012','PRIVACY CONCERNS'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00507','2 - Niederhuber (Andersen)','2','Newborn - 03','311','09/13/2012','PRIVACY CONCERNS'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00556','2 - Niederhuber (Andersen)','2','Father - 02','309','08/29/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00556','2 - Niederhuber (Andersen)','2','Mother - 01','310','08/29/2012','PROTOCOL NONCOMPLIANCE'
--INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '102-00556','2 - Niederhuber (Andersen)','2','Newborn - 03','311','08/29/2012','PROTOCOL NONCOMPLIANCE'

--insert study 101 data
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-059','withdrew','','','','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-098','withdrew','','','','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-114','withdrew','MISSING DAD','B, S, A','','B, S, A, P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-133','withdrew','MISSING DAD','B, S, A','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-154','withdrew','','B, S, A','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-168','withdrew','(missing FOB)','B, S, A','','A) B, S, A                     B) B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-211','withdrew',' (missing FOB)','B, S, A','','A) B, S, A                     B) B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-291','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-294','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-340','withdrew','','B, S, A','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-345','withdrew','','B, S, A','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-366','withdrew','','','B, S, A','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-378','withdrew','','B, S, A','','B, S, A, P',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-383','withdrew','','','B, S, A','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-407','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-416','withdrew','','B','','C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-418','withdrew','','B','','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-425','withdrew','','','B, S, A','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-429','withdrew','','','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-431','withdrew','','','','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-442','withdrew','','B, S, A','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-453','withdrew',' ','','B, S, A','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-475','withdrew','','B, S, A','','B, S, A, P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-484','withdrew','','B, S, A','B, S, A','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-493','withdrew','','B, S, A','','B, S, A, P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-496','withdrew','','','','B, S, A, P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-540','withdrew','','B, A','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-573','withdrew','','B, S, A','','B, S, A, P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-655','withdrew',' prior to samples being collected','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-674','withdrew','','','','B',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-685','withdrew','','','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-690','withdrew','','','','S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-691','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-701','withdrew','','','','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-707','withdrew','','B','','B, S, A, P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-721','withdrew','','B','','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-727','withdrew','','B, S, A','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-737','withdrew','','B, S, A','S, A','A)                              B) S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-761','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-767','withdrew','','','S, A','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-779','withdrew','','B, S, A','B, S, A','P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-829','withdrew','','S, A','B, S, A','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-916','withdrew','','B, S, A','','B, S, A, P, C',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-939','withdrew','','B, S, A','','A) B, S, A                     B) B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-950','withdrew','','B, S, A','S, A','S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-960','withdrew','','B, S, A','','B, S, A',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-332 (a)','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-214 (a)','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-201 (a)','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-221 (a)','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-189 (a)','withdrew','','','','',''
INSERT INTO #t (subject, site, sitenumber, instanceName, folderID, WDDAT_RAW, WDOTH) SELECT '101-120 (a)','withdrew','','','','',''


--delete any row where the subject is NULL [ITMIDW].[dbo].[tblSubjectWithDrawal]
DELETE FROM #T where subject IS NULL

--**Truncate table 
TRUNCATE TABLE [ITMIDW].[dbo].[tblSubjectWithDrawal]

--**INSERT Statement int o
INSERT INTO  [ITMIDW].[dbo].[tblSubjectWithDrawal]
           ([subjectID]
           ,[subjectWithReason]
           ,[SourceSystemID]
           ,[createdDate]
           ,[createdBy])
SELECT
 --(<subjectID, int,>
sub.subjectID
 --,<subjectWithReason, varchar(100),>
, CASE WHEN LEN(wdoth) =  0 THEN site ELSE wdoth END as withReason
 --,<SourceSystemID, int,>
, 13
 --,<createdDate, datetime,>
, GETDATE()
 --,<createdBy, varchar(100),>)
, 'ADB - Custom Script'
FROM #t	t
	 JOIN ITMIDW.dbo.tblsubject sub
		ON subject = 
			CASE
				WHEN LEFT(t.subject,3) = '101' 
					THEN REPLACE(REPLACE(REPLACE(sub.sourceSystemIDLabel,'F-',''),'M-',''),'NB-','')  --stripping family characters
				ELSE LEFT(sub.sourceSystemIDLabel,9) --stripping off the the family codes from the right side of ID
			END
--WHERE sub.subjectID IS NULL --**50 subjects are not in teh subject table
	
	
PRINT CAST(@@ROWCOUNT AS VARCHAR(10))+ ' row(s) updated.'

END
GO
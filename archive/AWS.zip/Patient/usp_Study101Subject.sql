IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Study101Subject]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Study101Subject]
GO
/**************************************************************************
Created On : 3/17/2014
Created By : Aaron Black
Team Name : Informatics
Object name : [usp_Study101Subject]
Functional : ITMI SSIS for Insert and Update for study 101 subjects
Purpose : Import of study 101 subjects from data spoint101 schema for Mom, dad and baby
History : Created on 3/17/2014
**************************************************************************
Date Modified By QC# Purposes
**************************************************************************
#Date #Comment
**************************************************************************
USE CASE:
EXEC [usp_Study101Subject]
--testing update and delete
--UPDATE tblsubject set studyID = 5 where sourceSystemIDLabel = 'F-101-066'
--select * from tblsubject where sourceSystemIDLabel = 'F-101-066'
--delete from tblsubject where sourceSystemIDLabel = 'F-101-201'
--select * from tblsubject where sourceSystemIDLabel = 'F-101-201'
**************************************************************************/
CREATE PROCEDURE [dbo].[usp_Study101Subject]
AS
BEGIN
SET NOCOUNT ON;
DECLARE @UpdatedOn SMALLDATETIME
SET @UpdatedOn = CAST(GETDATE() AS SMALLDATETIME)
PRINT CONVERT(CHAR(23), @UpdatedOn, 121) + ' [usp_Study101Subject][' + @@SERVERNAME + '][' + SYSTEM_USER + ']'
PRINT 'INSERT [ITMIDW].[dbo].[usp_Study101Subject]...'


--**************************************************************************
--*******[tblSubject]********DBCC CHECKIDENT('tblSubject', RESEED, 1)*******
--**************************************************************************
--drop table
IF OBJECT_ID('tempdb..#sourceSubject') IS NOT NULL
DROP TABLE #sourceSubject  


SELECT DISTINCT [sourceSystemSubjectID],[sourceSystemIDLabel],[studyID],[personID],[orgSourceSystemID],[createDate],[createdBy]
INTO #sourceSubject
FROM (
	SELECT 
		DISTINCT 
		a.[Fathers Study ID] as sourceSystemSubjectID
		,a.[Fathers Study ID] as sourceSystemIDLabel
		, (select stud.studyID from itmidw.dbo.tblStudy stud where stud.studyshortID like '%101%') as studyID
		, NULL as PersonID --will be part of insert later
		, 6 as [orgSourceSystemID]
		, GETDATE() as CreateDate
		, 'TSQL Import: adb'  AS createdBy
		FROM  itmistaging.[spoint101].[EDC101Father] a
			WHERE ISNULL(a.[Fathers Study ID],'' ) <> '' UNION ALL
	SELECT 
		a.[Mothers Study ID] as sourceSystemSubjectID
		, a.[Mothers Study ID] as sourceSystemIDLabel
		, (select stud.studyID from itmidw.dbo.tblStudy stud where stud.studyshortID like '%101%') as studyID
		, NULL as PersonID --will be part of insert later
		, 6 as [orgSourceSystemID]
		, GETDATE() as CreateDate
		, 'TSQL Import: adb'  AS createdBy
		FROM itmistaging.[spoint101].[EDC101Mother] a 
			WHERE ISNULL(a.[Mothers Study ID],'') <> '' UNION ALL
	SELECT 
		a.[Infants Study ID] as sourceSystemSubjectID
		, a.[Infants Study ID] as sourceSystemIDLabel
		, (select stud.studyID from itmidw.dbo.tblStudy stud where stud.studyshortID like '%101%') as studyID
		, NULL as PersonID --will be part of insert later
		, 6 as [orgSourceSystemID]
		, GETDATE() as CreateDate
		, 'TSQL Import: adb'  AS createdBy
		FROM itmistaging.[spoint101].[EDC101NEWBORN] a 
			WHERE ISNULL(a.[Infants Study ID],'') <> ''
	) AS B

--Slowly Changing dimension
MERGE  ITMIDW.[dbo].[tblSubject] AS targetSubject
USING #sourceSubject ss
	ON targetSubject.[sourceSystemSubjectID] = ss.[sourceSystemSubjectID]
WHEN MATCHED
	AND (
	ss.[studyID] <> targetSubject.[studyID] OR 
	ss.[sourceSystemIDLabel] <> targetSubject.[sourceSystemIDLabel] OR
	ss.[personID] <> targetSubject.[personID] OR
	ss.[orgSourceSystemID] <> targetSubject.[orgSourceSystemID] OR  
	ss.[createDate] <> targetSubject.[createDate] OR
	ss.[createdBy] <> targetSubject.[createdBy] 
	)
THEN UPDATE SET
	[studyID]  = ss.[studyID]
	, [sourceSystemIDLabel] = ss.[sourceSystemIDLabel]
	, [personID] = ss.[personID]
	, [orgSourceSystemID] = ss.[orgSourceSystemID]
	, [createDate] = ss.[createDate]
	, [createdBy] = ss.[createdBy] 
WHEN NOT MATCHED THEN

INSERT ([sourceSystemSubjectID],[sourceSystemIDLabel],[studyID],[personID],[orgSourceSystemID],[createDate],[createdBy])
VALUES (ss.[sourceSystemSubjectID],ss.[sourceSystemIDLabel],ss.[studyID],ss.[personID],ss.[orgSourceSystemID],ss.[createDate],ss.[createdBy]);


END




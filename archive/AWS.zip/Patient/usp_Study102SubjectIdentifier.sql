IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Study102SubjectIdentifier]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Study102SubjectIdentifier]
GO
/**************************************************************************
Created On : 3/17/2014
Created By : Aaron Black
Team Name : Informatics
Object name : [usp_Study102SubjectIdentifier]
Functional : ITMI SSIS for Insert and Update for study 102 subjects Identifiers
 forms, taking the distinct list of SubjectID's and making an insert.
History : Created on 3/17/2014
**************************************************************************
Date Modified By QC# Purposes
**************************************************************************
#Date #Comment
**************************************************************************
USE CASE:
EXEC [usp_Study102SubjectIdentifier]
--TRUNCATe table ITMIDW.[dbo].[tblSubjectIdentifer] 
--select * FROM ITMIDW.[dbo].[tblSubjectIdentifer]  order by subjectID, subjectidentifiertype
update ITMIDW.[dbo].[tblSubjectIdentifer]   set subjectIdentifier  = 'memaw' where subjectID = 6626
select * FROM ITMIDW.[dbo].[tblSubjectIdentifer]  where subjectID = 6626
delete from ITMIDW.[dbo].[tblSubjectIdentifer]  where subjectID = 6621
select * FROM ITMIDW.[dbo].[tblSubjectIdentifer]  where subjectID = 6621
**************************************************************************/
CREATE PROCEDURE [dbo].[usp_Study102SubjectIdentifier]
AS
BEGIN
SET NOCOUNT ON;
DECLARE @UpdatedOn SMALLDATETIME
SET @UpdatedOn = CAST(GETDATE() AS SMALLDATETIME)
PRINT CONVERT(CHAR(23), @UpdatedOn, 121) + ' [usp_Study102SubjectIdentifier][' + @@SERVERNAME + '][' + SYSTEM_USER + ']'
PRINT 'INSERT [ITMIDW].[dbo].[usp_Study102SubjectIdentifier]...'

--*************************************
--******************102****************
--*************************************
--drop table
IF OBJECT_ID('tempdb..#sourceSubjectIdentifier') IS NOT NULL
DROP TABLE #sourceSubjectIdentifier  

--UUID from DIFZ
SELECT 
           sub.subjectID as [subjectID]
           ,CONVERT(varchar(100),Participant.ParticipantID)  as [subjectIdentifier]
           ,'Source System DB ID' as [subjectIdentifierType]
           ,3 as [orgSourceSystemID]
           ,GETDATE()[createDate]
           ,'usp_Study102SubjectIdentifier' as [createdBy]
INTO #sourceSubjectIdentifier
	FROM ITMIDIFZ.genesis.Participant as Participant
		INNER JOIN ITMIDW.dbo.tblSubject sub
			on CONVERT(varchar(100),sub.[sourceSystemSubjectID]) = Convert(varchar(100),Participant.participantID)
				and sub.orgSourceSystemID = 3
	WHERE participant.isActive = 1

--Family ID - ITMI Specific

INSERT INTO #sourceSubjectIdentifier ([subjectID],[subjectIdentifier],[subjectIdentifierType],[orgSourceSystemID],[createDate],[createdBy])
SELECT 
           sub.subjectID as [subjectID]
           , sub.sourceSystemIDLabel as [subjectIdentifier]
           , 'ITMI Subject ID' as [subjectIdentifierType]
           , 3 as [orgSourceSystemID]
           , GETDATE()[createDate]
           , 'usp_Study102SubjectIdentifier' as [createdBy]
	FROM ITMIDIFZ.genesis.Participant as Participant
		INNER JOIN ITMIDW.dbo.tblSubject sub
			on CONVERT(varchar(100),sub.[sourceSystemSubjectID]) = Convert(varchar(100),Participant.participantID)
				and sub.orgSourceSystemID = 3
	WHERE participant.isActive = 1

INSERT INTO #sourceSubjectIdentifier ([subjectID],[subjectIdentifier],[subjectIdentifierType],[orgSourceSystemID],[createDate],[createdBy])
SELECT 
           sub.subjectID as [subjectID]
           , participant.medicalRecordNumber as [subjectIdentifier]
           , 'MRN' as [subjectIdentifierType]
           , 3 as [orgSourceSystemID]
           , GETDATE()[createDate]
           , 'usp_Study102SubjectIdentifier' as [createdBy]
	FROM ITMIDIFZ.genesis.Participant as Participant
		INNER JOIN ITMIDW.dbo.tblSubject sub
			on CONVERT(varchar(100),sub.[sourceSystemSubjectID]) = Convert(varchar(100),Participant.participantID)
				and sub.orgSourceSystemID = 3
	WHERE participant.isActive = 1
		and participant.medicalRecordNumber IS NOT NULL

		
--Slowly changing dimension
MERGE  ITMIDW.[dbo].[tblSubjectIdentifer] AS targetSubject
USING #sourceSubjectIdentifier ss
	ON targetSubject.subjectID = ss.subjectID
		AND targetSubject.subjectIdentifierType = ss.subjectIdentifierType
WHEN MATCHED
	AND (
		ss.[subjectIdentifier] <> targetSubject.[subjectIdentifier] OR
		ss.[orgSourceSystemID] <> targetSubject.[orgSourceSystemID] OR  
		ss.[createDate] <> targetSubject.[createDate] OR
		ss.[createdBy] <> targetSubject.[createdBy] 
	)
THEN UPDATE SET
	 [subjectIdentifier] = ss.[subjectIdentifier]
	, [orgSourceSystemID] = ss.[orgSourceSystemID]
	, [createDate] = ss.[createDate] 
	, [createdBy] = ss.[createdBy] 
WHEN NOT MATCHED THEN

INSERT ([subjectID],[subjectIdentifier],[subjectIdentifierType],[orgSourceSystemID],[createDate],[createdBy])
VALUES (ss.[subjectID],ss.[subjectIdentifier],ss.[subjectIdentifierType],ss.[orgSourceSystemID],ss.[createDate],ss.[createdBy]);

END



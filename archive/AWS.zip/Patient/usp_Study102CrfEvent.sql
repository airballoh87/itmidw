SELECT  
	deets.patientIdentifier
	, deets.itmiFormName
	, MIN(itmidw.dbo.dateonly(RaveCreatedDateTime)) as RaveCreatedDate
	, MIN(itmidw.dbo.dateonly(revieweddatetime)) as RaveReviewDate
FROM itmiDIFZ.genesis.PatientDataPointDetail as deets
	INNER JOIN ITMIDW.dbo.tblSubject subject
		ON subject.subjectId = deets.itmidwSubjectID
WHERE deets.isactive = 1	
GROUP BY deets.patientIdentifier, deets.itmiFormName
ORDER BY deets.patientIdentifier, deets.itmiFormName

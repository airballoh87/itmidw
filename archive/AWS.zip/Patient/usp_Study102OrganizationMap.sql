IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Study102OrganizationMap]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Study102OrganizationMap]
GO
/**************************************************************************
Created On : 3/29/2014
Created By : Aaron Black
Team Name : Informatics
Object name : [usp_Study102OrganizationMap]
Functional : ITMI SSIS for Insert and Update for study 102 tblOrganizationMap
 Which is attaching subjects to other entities, including family, original site where the subject was enrolled.  This is the map back
 to the subject
History : Created on 3/29/2014
**************************************************************************
Date Modified By QC# Purposes
**************************************************************************
#Date #Comment
**************************************************************************
USE CASE:
EXEC [usp_Study102OrganizationMap]
--TRUNCATe table ITMIDW.[dbo].[tblOrganization] 
--select * from ITMIDW.[dbo].[tblOrganization] 

**************************************************************************/
CREATE PROCEDURE [dbo].[usp_Study102OrganizationMap]
AS
BEGIN
SET NOCOUNT ON;
DECLARE @UpdatedOn SMALLDATETIME
SET @UpdatedOn = CAST(GETDATE() AS SMALLDATETIME)
PRINT CONVERT(CHAR(23), @UpdatedOn, 121) + ' [usp_Study102OrganizationMap][' + @@SERVERNAME + '][' + SYSTEM_USER + ']'
PRINT 'INSERT [ITMIDW].[dbo].[usp_Study102OrganizationMap]...'

--*************************************
--******************102****************
--*************************************
--drop table
IF OBJECT_ID('tempdb..#sourceOrganization') IS NOT NULL
DROP TABLE #sourceOrganization

TRUNCATE Table itmidw.dbo.tblsubjectOrganizationMap

--Family
SELECT DISTINCT
		   sub.subjectID as [subjectID]
           , org.organizationID as [organizationID]
           , org.organizationName  as [organizationTypeName]
INTO #sourceOrganization
	FROM ITMIDIFZ.genesis.Subject subject
		inner join ITMIDIFZ.genesis.Participant part
			on part.subjectID = subject.subjectId
		INNER JOIN itmidw.dbo.tblSubject sub
			on LTRIM(RTRIM(CONVERT(Varchar(100),sub.sourceSystemSubjectID))) = CONVERT(Varchar(100),part.participantID)
		INNER JOIN itmidw.dbo.tblOrganization org
			on CONVERT(Varchar(100),org.organizationCode) = CONVERT(Varchar(100),subject.subjectID)
	WHERE subject.isActive = 1
		
--Organization
INSERT INTO #sourceOrganization ([subjectID], [organizationID], [organizationTypeName])
	SELECT 
		   sub.subjectID as [subjectID]
           , org.organizationID as [organizationID]
           , org.organizationName  as [organizationTypeName]
	FROM ITMIDIFZ.genesis.Subject subject
		inner join ITMIDIFZ.genesis.Participant part
			on part.subjectID = subject.subjectId
		INNER JOIN itmidw.dbo.tblSubject sub
			on LTRIM(RTRIM(CONVERT(Varchar(100),sub.sourceSystemSubjectID))) = CONVERT(Varchar(100),part.participantID)
		INNER JOIN itmidifz.genesis.studysite site
			on site.studySiteID = subject.studySiteID
		INNER JOIN itmidifz.genesis.Organization difzOrg
			on difzOrg.organizationID = site.OrganizationID
		INNER JOIN itmidw.dbo.tblOrganization org
			on CONVERT(Varchar(100),org.organizationCode) =  ISNULL(CONVERT(varchar(50),DIFZorg.siteIdentifier), CONVERT(varchar(50),DIFZorg.organizationID))
	WHERE subject.isActive = 1
		


--Slowly changing dimension

INSERT INTO ITMIDW.[dbo].[tblSubjectOrganizationMap] ([subjectID],[organizationID],[organizationTypeName])
SELECT ss.[subjectID],ss.[organizationID],ss.[organizationTypeName] FROM #sourceOrganization ss


END



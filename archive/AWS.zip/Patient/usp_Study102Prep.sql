IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Study102Prep]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Study101Subject]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/**************************************************************************
Created On : 3/29/2014
Created By : Aaron Black
Team Name : Informatics
Object name : [usp_Study102Prep]
Functional : ITMI SSIS for preperation of staging files from DIFZ that will help in subsequent etl processes.
Purpose : Import of study 102 events for reporting and analysis
History : Created on 3/29/2014
**************************************************************************
Date Modified By QC# Purposes
**************************************************************************
#Date #Comment
**************************************************************************
USE CASE:
EXEC [usp_Study102Prep]
--testing update and delete
**************************************************************************/
CREATE PROCEDURE [dbo].[usp_Study102Prep]
AS
BEGIN


SET NOCOUNT ON;
DECLARE @UpdatedOn SMALLDATETIME
SET @UpdatedOn = CAST(GETDATE() AS SMALLDATETIME)
PRINT CONVERT(CHAR(23), @UpdatedOn, 121) + ' [usp_Study102Prep][' + @@SERVERNAME + '][' + SYSTEM_USER + ']'
PRINT 'INSERT [ITMIDW].[dbo].[usp_Study102Prep]...'


--**************************************************************************
--drop table
IF OBJECT_ID('tempdb..#metaForm') IS NOT NULL
DROP TABLE #metaForm  

IF exists(select * from itmidifz.sys.columns c
				inner join  itmidifz.sys.objects o
					on o.object_id = c.object_id
            where c.Name = 'itmidwSubjectID' and o.name ='PatientDataPointDetail')
ALTER TABLE itmidifz.genesis.PatientDataPointDetail DROP COLUMN  itmidwSubjectID 

IF exists(select * from itmidifz.sys.columns c
				inner join  itmidifz.sys.objects o
					on o.object_id = c.object_id
            where c.Name = 'itmiFormName' and o.name ='PatientDataPointDetail')
ALTER TABLE itmidifz.genesis.PatientDataPointDetail DROP COLUMN  itmiFormName 

IF exists(select * from itmidifz.sys.columns c
				inner join  itmidifz.sys.objects o
					on o.object_id = c.object_id
            where c.Name = 'itmiFieldName' and o.name ='PatientDataPointDetail')
ALTER TABLE itmidifz.genesis.PatientDataPointDetail DROP COLUMN  itmiFieldName 


ALTER TABLE itmidifz.genesis.PatientDataPointDetail ADD itmidwSubjectID INT
ALTER TABLE itmidifz.genesis.PatientDataPointDetail ADD itmiFormName VARCHAR(100)
ALTER TABLE itmidifz.genesis.PatientDataPointDetail ADD itmiFieldName VARCHAR(100)

--Temp table creation for form Data
SELECT 
	LTRIM(RTRIM(REPLACE(substring(crf.crfName,CHARINDEX(':',crf.crfName)+1,50),': 101',''))) as FormName
	, LTRIM(RTRIM(field.fieldname)) as FieldName
	, field.fieldDescription
INTO #metaForm
from itmiDW.dbo.tblcrffields  field 
	INNER JOIN itmidw.dbo.tblcrfVersion vers
		on vers.crfVersionID = field.crfVersionID
	INNER JOIN itmidw.dbo.tblcrf crf
		on crf.crfID = vers.crfID
WHERE field.fieldname <> ''
	and vers.orgSourceSystemID = (SELECT ss.sourceSystemID FROM ITMIDW.DBO.tblSourceSystem ss WHERE ss.sourceSystemSHortName = 'DIFZ')


UPDATE itmiDIFZ.genesis.PatientDataPointDetail SET itmidwSubjectID = subject.subjectID
	FROM itmiDIFZ.genesis.PatientDataPointDetail as deets
	INNER JOIN #metaForm mf
		on MF.fieldName = deets.fieldName
			and mf.formName = 
					CASE WHEN CHARINDEX(' -',deets.dataPageName) = 0 THEN deets.datapageName else 
						LEFT(deets.dataPageName,CHARINDEX(' -',deets.dataPageName)) END 
	INNER JOIN ITMIDW.dbo.tblSubject subject
		ON LTRIM(RTRIM(subject.sourceSystemIDLabel)) =  
			CASE deets.datapageName 
				WHEN 'Enrollment' THEN  deets.patientIdentifier + '-01'  
				WHEN 'Trio Contact' THEN deets.patientIdentifier + '-01'  
				WHEN 'Mother Socio-Economic Status ' THEN deets.patientIdentifier + '-01'  
					ELSE deets.patientIdentifier + '-' + LTRIM(RTRIM(SUBSTRING(deets.dataPageName, CHARINDEX('-',deets.datapageName)+1,5)))
			END 
WHERE deets.isactive = 1	

--fORM

UPDATE itmiDIFZ.genesis.PatientDataPointDetail   
	set itmiFormName = CASE WHEN CHARINDEX(' -',dataPageName) = 0 THEN datapageName else 
	LEFT(dataPageName,CHARINDEX(' -',dataPageName)) END 
FROM itmiDIFZ.genesis.PatientDataPointDetail as deets
	INNER JOIN ITMIDW.dbo.tblSubject subject
		ON subject.subjectId = deets.itmidwSubjectID
WHERE deets.isactive = 1	

--more descriptive fieldName
--itmiFieldName

UPDATE itmiDIFZ.genesis.PatientDataPointDetail   
	SET itmiFieldName = MF.fieldDescription
from #metaForm mf
	INNER JOIN itmiDIFZ.genesis.PatientDataPointDetail as deets
		ON deets.itmiFormName = mf.formName
			AND deets.fieldName = mf.FieldName
	INNER JOIN ITMIDW.dbo.tblSubject subject
		ON subject.subjectId = deets.itmidwSubjectID
WHERE deets.isactive = 1		
	
	
END
use itmidw
Go
--cleanup
truncate table tblsubject
truncate table tblperson
truncate table tblorganization
truncate table tblsubjectWithdrawal
truncate table tblSubjectIdentifer
truncate table tblEvent
truncate table tblCrfEvent
truncate table ITMIDW.[dbo].[tblCrfEventAnswers]

--subjects
exec [dbo].usp_Study101Subject
exec [dbo].usp_Study102Subject

--people
exec [dbo].[usp_Study101Person]
exec [dbo].[usp_Study102Person]

--withdrawal
exec [dbo].[usp_AllStudySubjectWithdrawal]
--Prep
exec itmistaging.[dbo].[usp_Study102Prep]

--subjects more
exec [dbo].[usp_Study102SubjectIdentifier]
exec [dbo].[usp_Study102Organization]
EXEC dbo.[usp_Study102OrganizationMap]

--Events
exec dbo.usp_Study102Event

--crf data
exec [usp_Study102CrfEvent]
exec [usp_Study102CrfData]
--specimens
exec usp_Study102SpecimenType



SELECT COUNT(*) as subjects FROM  tblsubject
SELECT COUNT(*) as people FROM tblperson
SELECT COUNT(*) as organization FROM tblorganization
SELECT COUNT(*) as withdraws FROM tblsubjectWithdrawal
SELECT COUNT(*) as subjectIDs FROM tblSubjectIdentifer
SELECT COUNT(*)  as Events FROM tblEvent
SELECT COUNT(*) as organizationMap FROM tblSubjectOrganizationMap
SELECT COUNT(*)  as spectype FROM tblSpecimenSampleType
SELECT COUNT(*)  as crfEvent FROM tblCrfEvent
SELECT COUNT(*)  as crfEvent FROM [tblCrfEventAnswers]
--select * from [tblCrfEventAnswers]